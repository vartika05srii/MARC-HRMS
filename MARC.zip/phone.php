<?php
?>
<html>
<head>
</head>
<body>
<h1>SMS Integration</h1>
<form action="apicode.php" method="post">
Mobile Number
<br/>

<input type="number" name="mobile"/>
<br/>	
<br/>
<input type="submit" value="send"/>
</form>
</body>
</html>