<?php
 mysql_connect("localhost","root","") or die("check database connection");
 mysql_select_db("marc") or die("check database connection");
?>